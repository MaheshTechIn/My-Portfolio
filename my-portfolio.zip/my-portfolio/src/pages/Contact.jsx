export default function Contact() {
  return <h1 className="text-4xl font-bold text-blue-400">Contact 📬</h1>;
}
